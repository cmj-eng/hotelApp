java -jar HotelGuestApp.jar
